# Unicode Character Database
# Date: 2018-06-04, 17:57:00 GMT [KW]
# © 2018 Unicode®, Inc.
# Unicode and the Unicode Logo are registered trademarks of Unicode, Inc. in the U.S. and other countries.
# For terms of use, see http://www.unicode.org/terms_of_use.html
#
# For documentation, see the following:
# NamesList.html
# UAX #38, "Unicode Han Database (Unihan)"
# UAX #44, "Unicode Character Database."
#
# The UAXes can be accessed at http://www.unicode.org/versions/Unicode11.0.0/

This directory contains the final data files
for the Unicode Character Database, for Version 11.0.0 of the Unicode Standard.
